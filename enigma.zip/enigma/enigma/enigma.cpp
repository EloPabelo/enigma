﻿#include "App.h"

int main() {
	App app;
	return 0;
}
